"""Record synthetic cases using the tested reporting engine, without a second engine."""
from copy import deepcopy
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from report import build_report


def scenarios():
    rows = json.loads((HERE.parent / 'sample.synthetic.json').read_text(encoding='utf-8'))
    zero = deepcopy(rows)
    zero[3]['shares'] = 0
    conflict = [deepcopy(rows[1]), deepcopy(rows[1])]
    conflict[1]['views'] = 1200
    items = [
        dict(id='latest', title='同一条内容，只留最新快照',
             detail='600和1000是同一内容两次累计观测，不能相加。区间外发布的内容也不进入本次汇总。', rows=rows),
        dict(id='zero', title='真实的0，与缺失不同',
             detail='仅将demo-notes的分享指标从null改为实际观测的0，其互动率才有完整的计算依据。', rows=zero),
        dict(id='conflict', title='同一时点冲突，停止出报告',
             detail='同平台、同内容、同一观测时间出现1000和1200两个浏览值，程序拒绝任意选一个。', rows=conflict),
    ]
    for item in items:
        try:
            item['report'] = build_report(item['rows'], '2026-10-26')
        except ValueError as exc:
            item['error'] = str(exc)
    return items


if __name__ == '__main__':
    payload = json.dumps(scenarios(), ensure_ascii=False).replace('<', '\\u003c')
    template = (HERE / 'template.html').read_text(encoding='utf-8')
    assert template.count('__SCENARIOS__') == 1
    (HERE / 'index.html').write_text(template.replace('__SCENARIOS__', payload), encoding='utf-8')
    print('Recorded 3 synthetic cases in web/index.html')
