# 合成案例交互演示

浏览器直接打开index.html即可离线查看三个固定案例。不上传文件、不调用外部API、不埋点；点击外部链接时会访问GitHub。浏览器切换录制结果，不实时执行Python。

复现：

```powershell
python -m unittest -v test_demo.py
python build_demo.py
```

build_demo.py使用父目录report.py实际生成每个案例的报告或错误，再将合成输入与结果嵌入template.html。index.html是生成成品；修改模板后应重新生成。新增案例的输出由现有统计引擎决定，未在浏览器复制一份算法。

已有样品与本演示均不是客户案例或商业系统。没有新增CSV/Excel导入、账号连接或托管数据能力。付费试做范围以仓库SERVICE.md为准。
