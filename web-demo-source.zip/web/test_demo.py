import unittest
from build_demo import scenarios


class DemoTests(unittest.TestCase):
    def test_latest_snapshot_is_not_added_twice(self):
        demo = scenarios()[0]
        self.assertEqual(demo['report']['input_rows'], 5)
        self.assertEqual(demo['report']['duplicate_snapshots'], 1)
        self.assertEqual(demo['report']['included_posts'], 3)
        video = next(p for p in demo['report']['platforms'] if p['platform'] == 'demo-video')
        self.assertEqual(video['views'], 1500)
        self.assertEqual(video['interaction_rate'], 0.06)

    def test_zero_is_distinct_from_missing(self):
        missing = scenarios()[0]['report']['platforms'][0]
        zero = scenarios()[1]['report']['platforms'][0]
        self.assertIsNone(missing['shares'])
        self.assertIsNone(missing['interaction_rate'])
        self.assertEqual(zero['shares'], 0)
        self.assertEqual(zero['interaction_rate'], 0.06)

    def test_conflict_has_no_success_report(self):
        conflict = scenarios()[2]
        self.assertNotIn('report', conflict)
        self.assertEqual(conflict['error'], 'Conflicting metrics for identical snapshot time')
        self.assertEqual(len(conflict['rows']), 2)


if __name__ == '__main__':
    unittest.main()
